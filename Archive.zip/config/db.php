<?php
        error_reporting(E_ALL);
        ini_set("display_errors", 1);
/**
 * Configuration for: Database Connection Grunnurinn
 */


define("DB_HOST", "db4free.net");
define("DB_PORT", "3306");
define("DB_DATABASE", "roomies");
define("DB_USER","ellertfinnbogi");
define("DB_PASSWORD","Tralli8");
