
<?php
    // must
phpinfo();

?>